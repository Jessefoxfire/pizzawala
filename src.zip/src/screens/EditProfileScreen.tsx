import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  Image,
  ScrollView,
  Modal,
} from 'react-native';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { updateEmail, updatePassword } from 'firebase/auth';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { db, auth } from '../services/firebase';
import { RootStackParamList } from '../navigation/AppNavigator';
import { Avatars, type AvatarKey } from '../../assets/avatars';

type Props = NativeStackScreenProps<RootStackParamList, 'EditProfile'>;

const avatarOptions: { id: AvatarKey }[] = Object.keys(Avatars).map(key => ({
  id: key as AvatarKey,
}));

export default function EditProfileScreen({ navigation }: Props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState<AvatarKey | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [avatarModalVisible, setAvatarModalVisible] = useState(false);

  const user = auth.currentUser;

  useEffect(() => {
    const loadProfile = async () => {
      if (!user?.uid) return;
      try {
        const docSnap = await getDoc(doc(db, 'users', user.uid));
        if (docSnap.exists()) {
          const data = docSnap.data();
          setName(data.name || '');
          setEmail(data.email || user.email || '');
          if (data.avatarUrl && data.avatarUrl in Avatars) {
            setSelectedAvatar(data.avatarUrl as AvatarKey);
          }
        } else {
          setEmail(user.email || '');
        }
      } catch (err) {
        console.error('Failed to load profile:', err);
      } finally {
        setLoading(false);
      }
    };

    loadProfile();
  }, [user]);

  const handleSave = async () => {
    if (!user?.uid) return;
    if (saving) return;

    const trimmedName = name.trim();
    const trimmedEmail = email.trim();

    if (!trimmedName || !trimmedEmail || !selectedAvatar) {
      Alert.alert('Error', 'Please fill in all fields and select an avatar.');
      return;
    }

    console.log('handleSave: starting', { trimmedName, trimmedEmail, selectedAvatar });
    setSaving(true);
    try {
      // Update Firestore profile
      console.log('handleSave: updating Firestore');
      await updateDoc(doc(db, 'users', user.uid), {
        name: trimmedName,
        email: trimmedEmail,
        emailLower: trimmedEmail.toLowerCase(),
        avatarUrl: selectedAvatar,
      });
      console.log('handleSave: Firestore updated');

      // Update email if changed
      if (trimmedEmail !== user.email) {
        console.log('handleSave: updating email');
        try {
          await updateEmail(user, trimmedEmail);
          console.log('handleSave: email updated');
        } catch (emailErr: any) {
          console.error('handleSave: email update failed', emailErr);
          // Email update might fail if user needs to re-authenticate
          if (emailErr.code === 'auth/requires-recent-login') {
            Alert.alert('Authentication Required', 'Please log out and log back in to change your email.');
          }
        }
      }

      // Update password if provided
      if (newPassword.trim()) {
        console.log('handleSave: updating password');
        try {
          await updatePassword(user, newPassword);
          console.log('handleSave: password updated');
        } catch (pwdErr: any) {
          console.error('handleSave: password update failed', pwdErr);
          // Password update might fail if user needs to re-authenticate
          if (pwdErr.code === 'auth/requires-recent-login') {
            Alert.alert('Authentication Required', 'Please log out and log back in to change your password.');
          }
        }
      }

      console.log('handleSave: success, showing alert');
      Alert.alert('Success', 'Profile updated successfully');
      console.log('handleSave: navigating back');
      navigation.goBack();
    } catch (err: any) {
      console.error('handleSave: error', err);
      const msg = err?.message || 'Failed to update profile';
      Alert.alert('Error', msg);
    } finally {
      console.log('handleSave: finally block, setting saving=false');
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" style={{ marginTop: 40 }} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Edit Profile</Text>
        <TouchableOpacity onPress={() => {
          console.log('Close button pressed');
          navigation.goBack();
        }}>
          <Text style={styles.closeText}>✕</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.card}>
          <Text style={styles.label}>Name</Text>
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="Your name"
            autoCapitalize="words"
          />

          <Text style={styles.label}>Email</Text>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder="your.email@example.com"
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <Text style={styles.label}>New Password (optional)</Text>
          <TextInput
            style={styles.input}
            value={newPassword}
            onChangeText={setNewPassword}
            placeholder="Leave blank to keep current"
            secureTextEntry
            autoCapitalize="none"
          />

          <Text style={styles.label}>Avatar</Text>
          <TouchableOpacity
            style={styles.avatarSelector}
            onPress={() => setAvatarModalVisible(true)}
          >
            {selectedAvatar ? (
              <Image source={Avatars[selectedAvatar]} style={styles.selectedAvatarImage} />
            ) : (
              <Text style={styles.avatarSelectorText}>Tap to select avatar</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.saveBtn}
            onPress={handleSave}
            disabled={saving}
          >
            {saving ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.saveBtnText}>Save Changes</Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Avatar Selection Modal */}
      <Modal visible={avatarModalVisible} transparent animationType="slide">
        <View style={styles.modalBg}>
          <View style={styles.modal}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Choose Your Avatar</Text>
              <TouchableOpacity
                onPress={() => setAvatarModalVisible(false)}
                style={styles.closeBtn}
              >
                <Text style={styles.closeText}>✕</Text>
              </TouchableOpacity>
            </View>
            <ScrollView>
              <View style={styles.avatarGrid}>
                {avatarOptions.map(avatar => (
                  <TouchableOpacity
                    key={avatar.id}
                    onPress={() => {
                      setSelectedAvatar(avatar.id);
                      setAvatarModalVisible(false);
                    }}
                    style={[
                      styles.avatarOption,
                      selectedAvatar === avatar.id && styles.avatarOptionSelected,
                    ]}
                  >
                    <Image source={Avatars[avatar.id]} style={styles.avatarImage} />
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#e77f39' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FEF6E4',
  },
  back: { fontSize: 18, fontWeight: 'bold' },
  title: { fontSize: 20, fontWeight: 'bold' },
  content: { padding: 16 },
  card: {
    backgroundColor: '#FEF6E4',
    borderRadius: 16,
    padding: 24,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginTop: 16,
    marginBottom: 8,
    color: '#3D352E',
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  avatarSelector: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#e0e0e0',
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 100,
  },
  selectedAvatarImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  avatarSelectorText: {
    color: '#999',
    fontSize: 14,
  },
  saveBtn: {
    backgroundColor: '#3D352E',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 24,
  },
  saveBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
  },
  modal: {
    margin: 20,
    backgroundColor: '#FEF6E4',
    borderRadius: 24,
    padding: 24,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: { fontSize: 20, fontWeight: 'bold', flex: 1 },
  closeBtn: {
    padding: 4,
    marginLeft: 8,
  },
  closeText: {
    fontSize: 28,
    color: '#3D352E',
    fontWeight: '300',
  },
  avatarGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  avatarOption: {
    width: '30%',
    aspectRatio: 1,
    marginBottom: 12,
    borderRadius: 12,
    borderWidth: 3,
    borderColor: 'transparent',
    overflow: 'hidden',
  },
  avatarOptionSelected: {
    borderColor: '#e77f39',
  },
  avatarImage: {
    width: '100%',
    height: '100%',
  },
});
