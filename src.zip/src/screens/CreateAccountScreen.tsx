
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  ScrollView,
  SafeAreaView,
  Image,
    KeyboardAvoidingView,
    Platform,
} from 'react-native';
import { createAccountWithEmail } from '../services/firebase';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { Icons } from '../components/Icons';
import { Avatars, type AvatarKey } from '../../assets/avatars';

type CreateAccountScreenProps = NativeStackScreenProps<RootStackParamList, 'CreateAccount'>;

const avatarOptions: { id: AvatarKey }[] = Object.keys(Avatars).map(key => ({
    id: key as AvatarKey,
}));

export default function CreateAccountScreen({ navigation }: CreateAccountScreenProps) {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [selectedAvatar, setSelectedAvatar] = useState<AvatarKey | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleCreateAccount = () => {
        if (!name.trim() || !email.trim() || !password.trim() || !selectedAvatar) {
            Alert.alert('Error', 'Please fill in all fields and select an avatar.');
            return;
        }

        setIsLoading(true);
        const avatarKey = selectedAvatar || '';
        
        createAccountWithEmail(name, email, password, avatarKey)
            .catch((error: any) => {
                const code = error?.code ? String(error.code) : '';
                if (code === 'auth/email-already-in-use') {
                    Alert.alert('Email already registered', 'Please log in instead.');
                    return;
                }
                Alert.alert('Account Creation Failed', 'Please try a different email or password.');
            })
            .finally(() => {
                setIsLoading(false);
            });
    };

    return (
        <SafeAreaView style={styles.container}>
            <KeyboardAvoidingView
                style={styles.flex}
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                keyboardVerticalOffset={Platform.OS === 'ios' ? 20 : 0}
            >
                <ScrollView
                    contentContainerStyle={styles.scrollContainer}
                    keyboardShouldPersistTaps="handled"
                >
                    <View style={styles.card}>
                        <TouchableOpacity
                            style={styles.homeButton}
                            onPress={() => navigation.replace('Login')}
                        >
                            <View style={styles.homeButtonContent}>
                                <Icons.home color="#3D352E" width={16} height={16} />
                                <Text style={styles.homeButtonText}>Home</Text>
                            </View>
                        </TouchableOpacity>
                    <Text style={styles.title}>Create Account</Text>
                    <Text style={styles.subtitle}>Join the Pizza Wala team.</Text>

                    <View style={styles.avatarSection}>
                        <Text style={styles.label}>Choose Your Avatar</Text>
                        <View style={styles.avatarGrid}>
                            {avatarOptions.map((avatar) => (
                                <TouchableOpacity
                                    key={avatar.id}
                                    style={[
                                        styles.avatarWrapper,
                                        selectedAvatar === avatar.id && styles.avatarSelected,
                                    ]}
                                    onPress={() => setSelectedAvatar(avatar.id)}
                                >
                                    <Image source={Avatars[avatar.id]} style={styles.avatarImage} />
                                    {selectedAvatar === avatar.id && (
                                        <View style={styles.avatarCheckmark}>
                                            <Icons.check color="#fff" width={16} height={16} />
                                        </View>
                                    )}
                                </TouchableOpacity>
                            ))}
                        </View>
                    </View>
                    
                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Full Name</Text>
                        <TextInput
                            placeholder="e.g. Tony Pepperoni"
                            value={name}
                            onChangeText={setName}
                            style={styles.input}
                            placeholderTextColor="#8F6A48"
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Email</Text>
                        <TextInput
                            placeholder="tony@pizzawala.com"
                            value={email}
                            onChangeText={setEmail}
                            style={styles.input}
                            autoCapitalize="none"
                            keyboardType="email-address"
                            placeholderTextColor="#8F6A48"
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Password</Text>
                        <View style={styles.passwordContainer}>
                            <TextInput
                                placeholder="Min. 6 characters"
                                value={password}
                                onChangeText={setPassword}
                                style={styles.passwordInput}
                                secureTextEntry={!showPassword}
                                placeholderTextColor="#8F6A48"
                            />
                            <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
                                {showPassword ? <Icons.eyeOff color="#fff" width={20} height={20} /> : <Icons.eye color="#fff" width={20} height={20} />}
                            </TouchableOpacity>
                        </View>
                    </View>

                    <TouchableOpacity
                        style={styles.button}
                        onPress={handleCreateAccount}
                        disabled={isLoading}
                    >
                        {isLoading ? <ActivityIndicator color="#3D352E" /> : <Text style={styles.buttonText}>Create Account</Text>}
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
                        <Text style={styles.backButtonText}>Already have an account? <Text style={styles.underline}>Log in</Text></Text>
                    </TouchableOpacity>
                    </View>
                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#e77f39' },
    flex: { flex: 1 },
    scrollContainer: {
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
        paddingBottom: 40,
    },
    card: { width: '100%', maxWidth: 380, backgroundColor: '#FEF6E4', paddingHorizontal: 24, paddingVertical: 32, borderRadius: 24, alignItems: 'center', elevation: 5 },
    homeButton: {
        alignSelf: 'flex-start',
        marginBottom: 12,
        backgroundColor: '#f6c07a',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 12,
        marginTop: -8,
    },
    homeButtonContent: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    homeButtonText: {
        fontSize: 14,
        color: '#3D352E',
        fontFamily: 'sans-serif',
        fontWeight: '600',
        marginLeft: 6,
    },
    title: { fontSize: 28, fontWeight: 'bold', color: '#3D352E', marginBottom: 8, fontFamily: 'sans-serif' },
    subtitle: { fontSize: 16, color: '#57493E', marginBottom: 24, textAlign: 'center', fontFamily: 'sans-serif' },
    inputGroup: { width: '100%', marginBottom: 16 },
    input: { width: '100%', backgroundColor: '#e77f39', paddingVertical: 14, paddingHorizontal: 16, borderRadius: 12, fontSize: 16, color: '#FFFFFF', fontWeight: '500', fontFamily: 'sans-serif' },
    passwordContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#e77f39', borderRadius: 12, width: '100%' },
    passwordInput: { flex: 1, paddingVertical: 14, paddingHorizontal: 16, fontSize: 16, color: '#FFFFFF', fontWeight: '500', fontFamily: 'sans-serif' },
    eyeIcon: { paddingRight: 16 },
    button: { backgroundColor: '#FDECC8', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 10, width: '100%' },
    buttonText: { fontWeight: '600', fontSize: 16, color: '#3D352E', fontFamily: 'sans-serif' },
    backButton: { marginTop: 24, padding: 10 },
    backButtonText: { color: '#57493E', fontSize: 14, textAlign: 'center', fontFamily: 'sans-serif' },
    underline: { textDecorationLine: 'underline' },
    avatarSection: { width: '100%', marginBottom: 20 },
    label: { fontSize: 14, fontWeight: '500', color: '#3D352E', marginBottom: 8, fontFamily: 'sans-serif' },
    avatarGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 12 },
    avatarWrapper: { width: 64, height: 64, borderRadius: 32, backgroundColor: '#FDECC8', justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: 'transparent' },
    avatarImage: { width: 48, height: 48 },
    avatarSelected: { borderColor: '#e77f39', backgroundColor: '#e77f39' },
    avatarCheckmark: { position: 'absolute', bottom: -2, right: -2, backgroundColor: '#3D352E', borderRadius: 12, width: 24, height: 24, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: '#FEF6E4' }
});
