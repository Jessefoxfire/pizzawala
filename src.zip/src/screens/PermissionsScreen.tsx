import React from 'react';
import { View, Text, StyleSheet, Button, Alert, Platform, PermissionsAndroid, Linking } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { configureBackgroundGeolocation } from '../utils/location';
import { ensureLocationPermission } from '../utils/geo';

type Props = NativeStackScreenProps<RootStackParamList, 'Permissions'>;

export default function PermissionsScreen({ navigation }: Props) {
  const requestPermission = async () => {
    try {
      const allowed = await ensureLocationPermission();
      if (!allowed) {
        Alert.alert('Permission required', 'Location permission is required.');
        return;
      }

      if (Platform.OS === 'android' && Platform.Version >= 29) {
        const bg = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_BACKGROUND_LOCATION
        );

        if (bg !== PermissionsAndroid.RESULTS.GRANTED) {
          // Background permission is optional for normal operation, but required for geofencing
          console.warn('Background location not granted - geofencing may not work');
        }
      }

      configureBackgroundGeolocation();
      navigation.replace('Home');
    } catch (error) {
      console.warn('Permissions error:', error);
      navigation.replace('Home');
    }
  };

  React.useEffect(() => {
    // Don't auto-request - let user tap button
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enable Location Access</Text>
      <Text style={styles.text}>
        PizzaWala uses location only to detect worksite entry and exit.
      </Text>
      <Button title="Allow location access" onPress={requestPermission} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 12,
  },
  text: {
    fontSize: 14,
    marginBottom: 24,
  },
});
