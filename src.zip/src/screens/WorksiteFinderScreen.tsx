import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  PermissionsAndroid,
  Platform,
  ActivityIndicator,
  Animated,
  TouchableOpacity,
  Image,
} from 'react-native';
import Geolocation from 'react-native-geolocation-service';
import MapView, { Circle, Marker, type Region } from 'react-native-maps';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/AppNavigator';
import { Avatars, type AvatarKey } from '../../assets/avatars';
import { auth, db } from '../services/firebase';
import { doc, onSnapshot, collection, query, where, updateDoc } from 'firebase/firestore';

type Props = NativeStackScreenProps<RootStackParamList, 'WorksiteFinder'>;

type Coordinates = { lat: number; lng: number };

const toRadians = (value: number) => (value * Math.PI) / 180;
const toDegrees = (value: number) => (value * 180) / Math.PI;

const getBearing = (from: Coordinates, to: Coordinates) => {
  const lat1 = toRadians(from.lat);
  const lat2 = toRadians(to.lat);
  const dLng = toRadians(to.lng - from.lng);
  const y = Math.sin(dLng) * Math.cos(lat2);
  const x =
    Math.cos(lat1) * Math.sin(lat2) -
    Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
  const bearing = toDegrees(Math.atan2(y, x));
  return (bearing + 360) % 360;
};

const getDistanceMeters = (from: Coordinates, to: Coordinates) => {
  const earthRadius = 6371000;
  const dLat = toRadians(to.lat - from.lat);
  const dLng = toRadians(to.lng - from.lng);
  const lat1 = toRadians(from.lat);
  const lat2 = toRadians(to.lat);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return earthRadius * c;
};

const formatDistance = (meters: number) => {
  if (meters < 1000) {
    return `${Math.round(meters)} m`;
  }
  return `${(meters / 1000).toFixed(2)} km`;
};

const WorksiteFinderScreen = ({ navigation, route }: Props) => {
  const { geofence } = route.params;
  const [position, setPosition] = useState<Coordinates | null>(null);
  const [heading, setHeading] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [userProfile, setUserProfile] = useState<any | null>(null);
  const [otherUsers, setOtherUsers] = useState<any[]>([]);
  const mapRef = useRef<MapView | null>(null);
  const pulse = useRef(new Animated.Value(0)).current;
  const user = auth.currentUser;

  const resolveAvatarSource = (avatar?: string | null) => {
    console.log('Resolving avatar:', avatar);
    if (!avatar) return null;
    if (avatar.startsWith('http')) return { uri: avatar };
    if (avatar in Avatars) {
      console.log('Found avatar in Avatars:', avatar);
      return Avatars[avatar as AvatarKey];
    }
    console.log('Avatar not found:', avatar);
    return null;
  };

  useEffect(() => {
    if (!user?.uid) return;
    const unsub = onSnapshot(doc(db, 'users', user.uid), snap => {
      if (snap.exists()) {
        const data = snap.data();
        console.log('User profile data:', data);
        console.log('Avatar URL:', data?.avatarUrl);
        setUserProfile(data);
      }
    });
    return () => unsub();
  }, [user?.uid]);

  // Listen to other users' locations
  useEffect(() => {
    if (!user?.uid) return;
    const usersQuery = query(
      collection(db, 'users'),
      where('__name__', '!=', user.uid)
    );
    const unsub = onSnapshot(usersQuery, snap => {
      const users = snap.docs
        .map(d => ({ id: d.id, ...d.data() }))
        .filter((u: any) => {
          // Only show users with recent location updates (within last 5 minutes)
          if (!u.lastLocation || !u.lastLocationUpdate) return false;
          const lastUpdate = u.lastLocationUpdate?.toDate?.() || new Date(u.lastLocationUpdate);
          const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
          return lastUpdate > fiveMinutesAgo;
        });
      setOtherUsers(users);
    });
    return () => unsub();
  }, [user?.uid]);

  // Update current user's location in Firestore
  useEffect(() => {
    if (!user?.uid || !position) return;
    
    const updateLocation = async () => {
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          lastLocation: { lat: position.lat, lng: position.lng },
          lastLocationUpdate: new Date(),
        });
      } catch (err) {
        console.error('Failed to update user location:', err);
      }
    };

    updateLocation();
    const interval = setInterval(updateLocation, 10000); // Update every 10 seconds
    
    return () => clearInterval(interval);
  }, [user?.uid, position]);

  useEffect(() => {
    let watchId: number | null = null;

    const ensureLocationPermission = async () => {
      if (Platform.OS === 'ios') {
        const auth = await Geolocation.requestAuthorization('whenInUse');
        console.log('iOS location auth status:', auth);
        return auth === 'granted';
      }
      if (Platform.OS !== 'android') return true;
      console.log('Requesting Android location permission');
      const fine = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
      );
      console.log('Android location permission result:', fine);
      return fine === PermissionsAndroid.RESULTS.GRANTED;
    };

    const startWatching = async () => {
      const allowed = await ensureLocationPermission();
      console.log('Location permission allowed:', allowed);
      if (!allowed) {
        console.error('Location permission denied - check Settings');
        setError('Location permission denied. Please enable in Settings.');
        return;
      }

      console.log('Getting current position...');
      Geolocation.getCurrentPosition(
        pos => {
          console.log('Got position:', pos.coords.latitude, pos.coords.longitude);
          setPosition({ lat: pos.coords.latitude, lng: pos.coords.longitude });
          const nextHeading = typeof pos.coords.heading === 'number'
            ? pos.coords.heading
            : null;
          setHeading(nextHeading);
          setError(''); // Clear any previous errors
        },
        err => {
          console.warn('getCurrentPosition error:', err);
          const errorMsg = err.code === 1
            ? 'Permission denied - check Settings'
            : err.code === 2
            ? 'Location unavailable. If using the iOS Simulator, set Features > Location.'
            : err.code === 3
            ? 'Location request timeout'
            : err.message || 'Unable to get location.';
          setError(errorMsg);
        },
        {
          enableHighAccuracy: true,
          timeout: 30000,
          maximumAge: 0,
        }
      );

      console.log('Setting up location watch...');
      watchId = Geolocation.watchPosition(
        pos => {
          console.log('Watch update:', pos.coords.latitude, pos.coords.longitude);
          setPosition({ lat: pos.coords.latitude, lng: pos.coords.longitude });
          const nextHeading = typeof pos.coords.heading === 'number'
            ? pos.coords.heading
            : null;
          setHeading(nextHeading);
        },
        err => {
          console.warn('watchPosition error:', err);
          const errorMsg = err.code === 2
            ? 'Location unavailable. If using the iOS Simulator, set Features > Location.'
            : err.message || 'Unable to get location.';
          setError(errorMsg);
        },
        {
          enableHighAccuracy: true,
          distanceFilter: 2,
          interval: 5000,
          fastestInterval: 2000,
          maximumAge: 0,
        }
      );
    };

    console.log('WorksiteFinderScreen: calling startWatching');
    startWatching();

    return () => {
      if (watchId !== null) {
        Geolocation.clearWatch(watchId);
      }
    };
  }, []);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 1400,
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 0,
          duration: 1400,
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulse]);

  const bearing = useMemo(() => {
    if (!position) return null;
    return getBearing(position, geofence.center);
  }, [position, geofence.center]);

  const distance = useMemo(() => {
    if (!position) return null;
    return getDistanceMeters(position, geofence.center);
  }, [position, geofence.center]);

  const rotation = useMemo(() => {
    if (bearing == null) return 0;
    const base = heading == null ? bearing : bearing - heading;
    return `${((base + 360) % 360).toFixed(0)}deg`;
  }, [bearing, heading]);

  const mapRegion = useMemo<Region>(() => {
    if (!position) {
      return {
        latitude: geofence.center.lat,
        longitude: geofence.center.lng,
        latitudeDelta: 0.02,
        longitudeDelta: 0.02,
      };
    }

    const dist = getDistanceMeters(position, geofence.center);
    const latDelta = Math.max(0.01, (dist / 111320) * 1.8);
    const lngDelta = Math.max(0.01, latDelta / Math.cos(toRadians(position.lat)));

    return {
      latitude: position.lat,
      longitude: position.lng,
      latitudeDelta: isFinite(latDelta) ? latDelta : 0.02,
      longitudeDelta: isFinite(lngDelta) ? lngDelta : 0.02,
    };
  }, [geofence.center, position]);

  useEffect(() => {
    if (mapRef.current) {
      mapRef.current.animateToRegion(mapRegion, 700);
    }
  }, [mapRegion]);

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        region={mapRegion}
        followsUserLocation
        pointerEvents="auto"
      >
        <Marker
          coordinate={{ latitude: geofence.center.lat, longitude: geofence.center.lng }}
          title={geofence.name}
          pinColor="#B35412"
        />
        <Circle
          center={{ latitude: geofence.center.lat, longitude: geofence.center.lng }}
          radius={geofence.radiusMeters}
          fillColor="rgba(181, 84, 18, 0.18)"
          strokeColor="rgba(181, 84, 18, 0.7)"
        />
        {position && (
          <Marker
            coordinate={{ latitude: position.lat, longitude: position.lng }}
            anchor={{ x: 0.5, y: 0.5 }}
            title="You"
          >
            <View style={styles.userMarker}>
              <Animated.View
                style={[
                  styles.userPulse,
                  {
                    opacity: pulse.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0.25, 0],
                    }),
                    transform: [
                      {
                        scale: pulse.interpolate({
                          inputRange: [0, 1],
                          outputRange: [0.6, 1.8],
                        }),
                      },
                    ],
                  },
                ]}
              />
              <View style={styles.userDot} />
            </View>
          </Marker>
        )}
        {otherUsers.map(otherUser => {
          if (!otherUser.lastLocation) return null;
          const avatarSource = resolveAvatarSource(otherUser.avatarUrl);
          return (
            <Marker
              key={otherUser.id}
              coordinate={{
                latitude: otherUser.lastLocation.lat,
                longitude: otherUser.lastLocation.lng,
              }}
              anchor={{ x: 0.5, y: 0.5 }}
              title={otherUser.name || 'User'}
            >
              <View style={styles.otherUserMarker}>
                {avatarSource ? (
                  <Image
                    source={avatarSource}
                    style={styles.otherUserAvatar}
                    resizeMode="cover"
                  />
                ) : (
                  <View style={styles.otherUserPlaceholder} />
                )}
              </View>
            </Marker>
          );
        })}
      </MapView>

      <View style={styles.overlay} pointerEvents="box-none">
        <View style={styles.card}>
          {error ? (
            <Text style={styles.errorText}>{error}</Text>
          ) : !position ? (
            <ActivityIndicator color="#E6FFF3" />
          ) : (
            <View style={styles.compassWrap}>
              <View style={styles.compass}>
                <View style={styles.compassRing} />
                <View style={styles.crosshairVertical} />
                <View style={styles.crosshairHorizontal} />
                <View style={[styles.arrow, { transform: [{ rotate: rotation }] }]} />
                {resolveAvatarSource(userProfile?.avatarUrl) ? (
                  <View style={styles.centerAvatarWrap}>
                    <Image
                      source={resolveAvatarSource(userProfile?.avatarUrl)!}
                      style={styles.centerAvatar}
                      resizeMode="cover"
                    />
                  </View>
                ) : (
                  <View style={styles.compassCenter} />
                )}
              </View>
            </View>
          )}
        </View>

        <View style={styles.bottomReadout}>
          <View style={styles.readoutPanel}>
            <View style={styles.readoutRow}>
              <Text style={styles.readoutLabel}>NAVIGATING TO:</Text>
              <Text style={styles.readoutValueLine}>{geofence.name}</Text>
            </View>
            <View style={styles.readoutDivider} />
            <View style={styles.readoutRow}>
              <Text style={styles.readoutLabel}>DISTANCE TO DESTINATION:</Text>
              <View style={styles.readoutBox}>
                <Text style={styles.readoutValue}>
                  {distance ? formatDistance(distance) : '--'}
                </Text>
              </View>
            </View>
          </View>
        </View>
      </View>

      <TouchableOpacity
        style={styles.closeButton}
        onPress={() => {
          console.log('Close button pressed - navigating back');
          navigation.goBack();
        }}
        activeOpacity={0.7}
      >
        <Text style={styles.closeButtonText}>×</Text>
      </TouchableOpacity>
    </View>
  );
};

export default WorksiteFinderScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e77f39',
  },
  closeButton: {
    position: 'absolute',
    top: 50,
    right: 20,
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(18, 90, 58, 0.35)',
    borderWidth: 2,
    borderColor: 'rgba(120, 255, 200, 0.45)',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 999,
    zIndex: 99999,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.6,
    shadowRadius: 6,
  },
  closeButtonText: {
    color: '#E6FFF3',
    fontSize: 28,
    fontWeight: '700',
    lineHeight: 28,
  },
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  card: {
    width: 300,
    height: 300,
    backgroundColor: 'rgba(18, 90, 58, 0.245)',
    borderRadius: 150,
    padding: 18,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    borderWidth: 1,
    borderColor: 'rgba(120, 255, 200, 0.35)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.25,
    shadowRadius: 14,
    elevation: 8,
  },
  compassWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomReadout: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 24,
    alignItems: 'center',
  },
  readoutPanel: {
    width: '100%',
    maxWidth: 420,
    backgroundColor: 'rgba(8, 16, 12, 0.78)',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(120, 255, 200, 0.6)',
    paddingVertical: 12,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 8,
  },
  readoutRow: {
    alignItems: 'center',
  },
  readoutDivider: {
    height: 1,
    marginVertical: 10,
    backgroundColor: 'rgba(120, 255, 200, 0.25)',
  },
  readoutLabel: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.1,
    color: '#C9FFE8',
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.6)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },
  readoutBox: {
    marginTop: 6,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(120, 255, 200, 0.7)',
    backgroundColor: 'rgba(8, 20, 16, 0.65)',
  },
  readoutValue: {
    fontSize: 18,
    fontWeight: '800',
    color: '#7FFFCB',
    letterSpacing: 0.6,
    textAlign: 'center',
  },
  readoutValueLine: {
    marginTop: 6,
    fontSize: 16,
    fontWeight: '700',
    color: '#E6FFF3',
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.6)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },
  compass: {
    width: 150,
    height: 150,
    borderRadius: 75,
    borderWidth: 2,
    borderColor: 'rgba(120, 255, 200, 0.45)',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(8, 20, 16, 0.32)',
  },
  compassRing: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 1,
    borderColor: 'rgba(120, 255, 200, 0.35)',
  },
  crosshairVertical: {
    position: 'absolute',
    width: 2,
    height: 130,
    backgroundColor: 'rgba(120, 255, 200, 0.25)',
  },
  crosshairHorizontal: {
    position: 'absolute',
    width: 130,
    height: 2,
    backgroundColor: 'rgba(120, 255, 200, 0.25)',
  },
  compassCenter: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#7FFFCB',
    position: 'absolute',
    left: '50%',
    top: '50%',
    marginLeft: -4,
    marginTop: -4,
  },
  centerAvatarWrap: {
    position: 'absolute',
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 3,
    borderColor: '#7FFFCB',
    backgroundColor: '#0B2A1D',
    alignItems: 'center',
    justifyContent: 'center',
    left: '50%',
    top: '50%',
    marginLeft: -32,
    marginTop: -32,
    shadowColor: '#7FFFCB',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
    elevation: 5,
  },
  centerAvatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
  },
  arrow: {
    position: 'absolute',
    top: '50%',
    marginTop: -40,
    width: 0,
    height: 0,
    borderLeftWidth: 16,
    borderRightWidth: 16,
    borderBottomWidth: 40,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: '#7FFFCB',
  },
  errorText: {
    fontSize: 14,
    color: '#FFD6DE',
    textAlign: 'center',
  },
  userMarker: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userPulse: {
    position: 'absolute',
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(127, 255, 203, 0.65)',
  },
  userDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#7FFFCB',
    borderWidth: 2,
    borderColor: '#0D1A14',
  },
  otherUserMarker: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 3,
    borderColor: '#4A90E2',
    backgroundColor: '#fff',
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  otherUserAvatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
  },
  otherUserPlaceholder: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#4A90E2',
  },
});
