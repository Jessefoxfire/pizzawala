import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
  Switch,
} from 'react-native';
import { collection, deleteDoc, doc, onSnapshot, updateDoc } from 'firebase/firestore';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { db, resetPassword } from '../services/firebase';
import { RootStackParamList } from '../navigation/AppNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'ManageUsers'>;

type UserRecord = {
  id: string;
  name?: string;
  email?: string;
  emailLower?: string;
  roles?: string[];
  disabled?: boolean;
};

export default function ManageUsersScreen({ navigation }: Props) {
  const [users, setUsers] = useState<UserRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<UserRecord | null>(null);
  const [editVisible, setEditVisible] = useState(false);
  const [editName, setEditName] = useState('');
  const [editAdmin, setEditAdmin] = useState(false);
  const [saving, setSaving] = useState(false);
  const [resettingId, setResettingId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'users'), snap => {
      const items = snap.docs.map(docSnap => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<UserRecord, 'id'>),
      }));
      setUsers(items);
      setLoading(false);
    });

    return () => unsub();
  }, []);

  const sortedUsers = useMemo(() => {
    return [...users].sort((a, b) => {
      const aName = (a.name || a.emailLower || a.email || '').toLowerCase();
      const bName = (b.name || b.emailLower || b.email || '').toLowerCase();
      return aName.localeCompare(bName);
    });
  }, [users]);

  const openEdit = (user: UserRecord) => {
    setSelected(user);
    setEditName(user.name || '');
    const roles = Array.isArray(user.roles) ? user.roles : [];
    setEditAdmin(roles.includes('admin'));
    setEditVisible(true);
  };

  const handleSave = async () => {
    if (!selected) return;
    if (saving) return;
    const trimmed = editName.trim();

    console.log('handleSave: starting', { selectedId: selected.id, trimmed, editAdmin });
    setSaving(true);
    try {
      const roles = Array.isArray(selected.roles) ? selected.roles : [];
      const nextRoles = editAdmin
        ? Array.from(new Set([...roles, 'admin']))
        : roles.filter(role => role !== 'admin');

      console.log('handleSave: updating with', { name: trimmed, roles: nextRoles });
      await updateDoc(doc(db, 'users', selected.id), {
        name: trimmed,
        roles: nextRoles,
      });

      console.log('handleSave: success');
      setEditVisible(false);
      setSelected(null);
      setEditName('');
      setEditAdmin(false);
      Alert.alert('Success', 'User updated successfully');
    } catch (err: any) {
      console.error('handleSave: error', err);
      const msg = err?.message ? String(err.message) : 'Unable to update user.';
      Alert.alert('Error', msg);
    } finally {
      console.log('handleSave: finally block');
      setSaving(false);
    }
  };

  const handleResetPassword = async (user: UserRecord) => {
    const targetEmail = user.emailLower || user.email || '';
    if (!targetEmail) {
      Alert.alert('No email', 'This user has no email on file.');
      return;
    }

    setResettingId(user.id);
    try {
      await resetPassword(targetEmail);
      Alert.alert('Reset Email Sent', `Sent to ${targetEmail}.`);
    } catch (err: any) {
      const msg = err?.message ? String(err.message) : 'Unable to send reset email.';
      Alert.alert('Reset Failed', msg);
    } finally {
      setResettingId(null);
    }
  };

  const handleToggleDisabled = async (user: UserRecord) => {
    try {
      const next = !user.disabled;
      await updateDoc(doc(db, 'users', user.id), { disabled: next });
    } catch (err: any) {
      const msg = err?.message ? String(err.message) : 'Unable to update status.';
      Alert.alert('Error', msg);
    }
  };

  const handleDeleteProfile = (user: UserRecord) => {
    Alert.alert(
      'Delete Profile Data',
      `Remove profile data for ${user.email || user.name || 'this user'}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteDoc(doc(db, 'users', user.id));
            } catch (err: any) {
              const msg = err?.message ? String(err.message) : 'Unable to delete.';
              Alert.alert('Error', msg);
            }
          },
        },
      ]
    );
  };

  const renderItem = ({ item }: { item: UserRecord }) => {
    const roles = Array.isArray(item.roles) ? item.roles : [];
    const label = item.name || item.email || 'Unnamed user';

    return (
      <View style={styles.userCard}>
        <View style={styles.userHeader}>
          <View style={{ flex: 1 }}>
            <Text style={styles.userName}>{label}</Text>
            {!!item.email && <Text style={styles.userEmail}>{item.email}</Text>}
            <Text style={styles.userMeta}>
              {roles.includes('admin') ? 'Admin' : 'Member'}
              {item.disabled ? ' • Disabled' : ''}
            </Text>
          </View>
          <TouchableOpacity style={styles.editBtn} onPress={() => openEdit(item)}>
            <Text style={styles.editBtnText}>Edit</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.actionsRow}>
          <TouchableOpacity
            style={styles.actionBtn}
            onPress={() => handleResetPassword(item)}
            disabled={resettingId === item.id}
          >
            {resettingId === item.id ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.actionText}>Send Reset</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: '#6D4C41' }]}
            onPress={() => handleToggleDisabled(item)}
          >
            <Text style={styles.actionText}>
              {item.disabled ? 'Activate' : 'Disable'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: '#B71C1C' }]}
            onPress={() => handleDeleteProfile(item)}
          >
            <Text style={styles.actionText}>Delete Profile</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ Home</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Manage Users</Text>
        <View style={{ width: 60 }} />
      </View>

      {loading ? (
        <ActivityIndicator size="large" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={sortedUsers}
          renderItem={renderItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.list}
          ListEmptyComponent={
            <Text style={styles.empty}>No users found.</Text>
          }
        />
      )}

      <Modal visible={editVisible} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit User</Text>
              <TouchableOpacity
                onPress={() => {
                  setEditVisible(false);
                  setSelected(null);
                  setEditName('');
                  setEditAdmin(false);
                  setSaving(false);
                }}
                style={styles.closeBtn}
              >
                <Text style={styles.closeText}>✕</Text>
              </TouchableOpacity>
            </View>
            <TextInput
              style={styles.input}
              value={editName}
              onChangeText={setEditName}
              placeholder="Full name"
            />
            <View style={styles.toggleRow}>
              <Text style={styles.toggleLabel}>Admin access</Text>
              <Switch value={editAdmin} onValueChange={setEditAdmin} />
            </View>
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalLink}
                onPress={() => {
                  setEditVisible(false);
                  setSelected(null);
                  setEditName('');
                  setEditAdmin(false);
                  setSaving(false);
                }}
              >
                <Text style={styles.modalLinkText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={handleSave}
                disabled={saving}
              >
                {saving ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.modalButtonText}>Save</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: '#e77f39',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FEF6E4',
  },
  back: { fontSize: 18, fontWeight: 'bold' },
  title: { fontSize: 20, fontWeight: 'bold' },
  list: { padding: 16 },
  empty: { textAlign: 'center', marginTop: 40, color: '#3D352E' },
  userCard: {
    backgroundColor: '#FEF6E4',
    padding: 16,
    borderRadius: 16,
    marginBottom: 12,
  },
  userHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userName: { fontSize: 16, fontWeight: 'bold', color: '#2A1D14' },
  userEmail: { fontSize: 13, color: '#5A3B2E', marginTop: 2 },
  userMeta: { fontSize: 12, color: '#6D4C41', marginTop: 6 },
  editBtn: {
    backgroundColor: '#3D352E',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  editBtnText: { color: '#fff', fontWeight: '600', fontSize: 12 },
  actionsRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
  actionBtn: {
    flex: 1,
    backgroundColor: '#E58F3A',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  actionText: { color: '#2A1D14', fontWeight: '600', fontSize: 12 },
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
  },
  modalCard: {
    margin: 20,
    backgroundColor: '#FEF6E4',
    borderRadius: 20,
    padding: 20,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  modalTitle: { fontSize: 18, fontWeight: 'bold', flex: 1 },
  closeBtn: {
    padding: 4,
    marginLeft: 8,
  },
  closeText: {
    fontSize: 24,
    color: '#3D352E',
    fontWeight: '300',
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginTop: 16,
  },
  toggleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 16,
  },
  toggleLabel: { fontSize: 14, color: '#3D352E' },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 20,
  },
  modalLink: { padding: 8 },
  modalLinkText: { color: '#3D352E', fontWeight: '600' },
  modalButton: {
    backgroundColor: '#3D352E',
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 8,
  },
  modalButtonText: { color: '#fff', fontWeight: '600' },
});
