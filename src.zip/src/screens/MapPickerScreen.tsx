
import React, { useRef, useState, useEffect } from 'react';
import {
    View,
    StyleSheet,
    TouchableOpacity,
    Text,
    SafeAreaView,
    TextInput,
    Platform,
    FlatList,
    ActivityIndicator,
    Keyboard,
    Alert,
} from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import Geolocation from 'react-native-geolocation-service';
import { ensureLocationPermission } from '../utils/geo';

export default function MapPickerScreen({ route, navigation }: any) {
    const onLocationSelected = route?.params?.onLocationSelected;
    const [selectedLocation, setSelectedLocation] = useState<{lat: number, lng: number} | null>(null);
    const [query, setQuery] = useState('');
    const [results, setResults] = useState<any[]>([]);
    const [searching, setSearching] = useState(false);
    const mapRef = useRef<MapView | null>(null);

    const handleConfirm = () => {
        if (selectedLocation) {
            if (typeof onLocationSelected === 'function') {
                onLocationSelected(selectedLocation.lat, selectedLocation.lng);
            } else {
                Alert.alert('Error', 'Unable to return selected location. Please try again.');
            }
            navigation.goBack();
        }
    };

    const performSearch = async () => {
        if (!query || query.trim() === '') return;
        setSearching(true);
        Keyboard.dismiss();
        try {
            // Use Nominatim OpenStreetMap geocoding (no API key)
            const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
                query
            )}&limit=6`;
            const res = await fetch(url, { headers: { 'User-Agent': 'PizzaWala/1.0' } });
            const json = await res.json();
            const mapped = (json || []).map((r: any) => ({
                lat: parseFloat(r.lat),
                lng: parseFloat(r.lon),
                display: r.display_name,
            }));
            setResults(mapped);
        } catch (e) {
            setResults([]);
        } finally {
            setSearching(false);
        }
    };

    const selectResult = (item: any) => {
        setSelectedLocation({ lat: item.lat, lng: item.lng });
        setResults([]);
        // move map
        if (mapRef.current) {
            mapRef.current.animateToRegion(
                {
                    latitude: item.lat,
                    longitude: item.lng,
                    latitudeDelta: 0.01,
                    longitudeDelta: 0.01,
                },
                300
            );
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Text style={styles.backBtn}>Cancel</Text>
                </TouchableOpacity>
                <Text style={styles.title}>Pick Location</Text>
                <TouchableOpacity onPress={handleConfirm} disabled={!selectedLocation}>
                    <Text style={[styles.backBtn, !selectedLocation && {color: '#ccc'}]}>Confirm</Text>
                </TouchableOpacity>
            </View>
            {/* Search bar */}
            <View style={styles.searchBarContainer}>
                <TextInput
                    placeholder="Search address or place"
                    value={query}
                    onChangeText={setQuery}
                    onSubmitEditing={performSearch}
                    style={styles.searchInput}
                    returnKeyType="search"
                />
                <TouchableOpacity onPress={performSearch} style={styles.searchBtn}>
                    {searching ? (
                        <ActivityIndicator color="#fff" />
                    ) : (
                        <Text style={styles.searchBtnText}>Search</Text>
                    )}
                </TouchableOpacity>
            </View>

            <MapView
                ref={r => (mapRef.current = r)}
                style={styles.map}
                provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined}
                initialRegion={{
                    latitude: 34.0522,
                    longitude: -118.2437,
                    latitudeDelta: 0.0922,
                    longitudeDelta: 0.0421,
                }}
                onPress={(e) => {
                    const { latitude, longitude } = e.nativeEvent.coordinate;
                    setSelectedLocation({ lat: latitude, lng: longitude });
                    // Immediately return the picked coordinates to the caller and close picker
                    if (typeof onLocationSelected === 'function') {
                        onLocationSelected(latitude, longitude);
                    }
                    navigation.goBack();
                }}
            >
                {selectedLocation && (
                    <Marker coordinate={{ latitude: selectedLocation.lat, longitude: selectedLocation.lng }} />
                )}
            </MapView>

            {/* Search results dropdown */}
            {results.length > 0 && (
                <View style={styles.resultsContainer}>
                    <FlatList
                        data={results}
                        keyExtractor={(i, idx) => `${i.lat}-${i.lng}-${idx}`}
                        renderItem={({ item }) => (
                            <TouchableOpacity onPress={() => selectResult(item)} style={styles.resultRow}>
                                <Text numberOfLines={1} style={styles.resultText}>{item.display}</Text>
                            </TouchableOpacity>
                        )}
                    />
                </View>
            )}

            <View style={styles.instructions}>
                <Text style={styles.instructionText}>Tap the map to place a pin</Text>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#FFF' },
    header: { flexDirection: 'row', justifyContent: 'space-between', padding: 16, borderBottomWidth: 1, borderBottomColor: '#eee' },
    backBtn: { fontSize: 16, fontWeight: 'bold', color: '#e77f39' },
    title: { fontSize: 18, fontWeight: 'bold' },
    map: { flex: 1 },
    instructions: { position: 'absolute', bottom: 40, width: '100%', alignItems: 'center' },
    instructionText: { backgroundColor: 'rgba(0,0,0,0.7)', color: '#fff', padding: 10, borderRadius: 20 }
    ,
    searchBarContainer: {
        position: 'absolute',
        top: 72,
        left: 16,
        right: 16,
        zIndex: 30,
        flexDirection: 'row',
        alignItems: 'center',
    },
    searchInput: {
        flex: 1,
        backgroundColor: '#fff',
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#ddd',
        marginRight: 8,
    },
    searchBtn: {
        backgroundColor: '#3D352E',
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 8,
    },
    searchBtnText: { color: '#fff', fontWeight: 'bold' },
    resultsContainer: {
        position: 'absolute',
        top: 120,
        left: 16,
        right: 16,
        maxHeight: 240,
        backgroundColor: '#fff',
        borderRadius: 8,
        zIndex: 40,
        borderWidth: 1,
        borderColor: '#eee',
    },
    resultRow: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#f4f4f4' },
    resultText: { fontSize: 14 },
});
