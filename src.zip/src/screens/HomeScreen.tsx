import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Alert,
  Modal,
  TextInput,
  Switch,
  ActivityIndicator,
  Image,
} from 'react-native';
import { onAuthStateChanged } from 'firebase/auth';
import {
  collection,
  doc,
  getDocs,
  onSnapshot,
  query,
  updateDoc,
  where,
} from 'firebase/firestore';
import { signOutUser, auth, db } from '../services/firebase';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import type { Geofence } from '../utils/types';
import { Avatars, type AvatarKey } from '../../assets/avatars';

export default function HomeScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Home'>>();
  const [userName, setUserName] = useState<string>('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminModalVisible, setAdminModalVisible] = useState(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [grantAdmin, setGrantAdmin] = useState(true);
  const [adminSaving, setAdminSaving] = useState(false);
  const [worksites, setWorksites] = useState<Geofence[]>([]);
  const [worksitePickerVisible, setWorksitePickerVisible] = useState(false);
  const [selectedWorksite, setSelectedWorksite] = useState<Geofence | null>(null);
  const welcomeText = userName ? `Welcome ${userName}` : 'Welcome';
  const sortedWorksites = useMemo(
    () => [...worksites].sort((a, b) => a.name.localeCompare(b.name)),
    [worksites]
  );

  useEffect(() => {
    let unsubProfile: (() => void) | null = null;

    const unsubAuth = onAuthStateChanged(auth, user => {
      setUserName(user?.displayName || '');

      if (unsubProfile) {
        unsubProfile();
        unsubProfile = null;
      }

      if (!user) {
        setIsAdmin(false);
        return;
      }

      const profileRef = doc(db, 'users', user.uid);
      unsubProfile = onSnapshot(profileRef, snap => {
        const data = snap.data();
        const roles = data?.roles;
        const name = data?.name;
        const avatar = data?.avatarUrl;
        setIsAdmin(Array.isArray(roles) && roles.includes('admin'));
        if (typeof name === 'string' && name.trim()) {
          setUserName(name);
        }
        setAvatarUrl(avatar || null);
      });
    });

    return () => {
      if (unsubProfile) {
        unsubProfile();
      }
      unsubAuth();
    };
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'geofences'));
    const unsub = onSnapshot(q, snap => {
      const items = snap.docs.map(d => ({ id: d.id, ...d.data() })) as Geofence[];
      setWorksites(items);
    });

    return () => unsub();
  }, []);

  const handleAdminRoleUpdate = async () => {
    if (adminSaving) return;

    const trimmed = adminEmail.trim();
    if (!trimmed) {
      Alert.alert('Email required', 'Enter a user email to update roles.');
      return;
    }

    setAdminSaving(true);
    try {
      const usersRef = collection(db, 'users');
      const normalized = trimmed.toLowerCase();

      let snap = await getDocs(query(usersRef, where('emailLower', '==', normalized)));
      if (snap.empty) {
        snap = await getDocs(query(usersRef, where('email', '==', trimmed)));
      }

      if (snap.empty) {
        throw new Error('User not found.');
      }

      await Promise.all(
        snap.docs.map(docSnap => {
          const data = docSnap.data();
          const roles = Array.isArray(data.roles) ? data.roles : [];
          const nextRoles = grantAdmin
            ? Array.from(new Set([...roles, 'admin']))
            : roles.filter(role => role !== 'admin');
          return updateDoc(doc(db, 'users', docSnap.id), { roles: nextRoles });
        })
      );

      Alert.alert('Success', grantAdmin ? 'Admin role granted.' : 'Admin role removed.');
      setAdminEmail('');
      setAdminModalVisible(false);
    } catch (error: any) {
      const message = error?.message ? String(error.message) : 'Unable to update roles.';
      Alert.alert('Error', message);
    } finally {
      setAdminSaving(false);
    }
  };
  const handleNavigatorPress = () => {
    if (sortedWorksites.length === 0) {
      Alert.alert('No worksites', 'There are no worksites available yet.');
      return;
    }
    setWorksitePickerVisible(true);
  };

  const handleSelectWorksite = (worksite: Geofence) => {
    setSelectedWorksite(worksite);
    setWorksitePickerVisible(false);
    navigation.navigate('WorksiteFinder', { geofence: worksite });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.center}>
        {isAdmin && (
          <View style={styles.card}>
            <Text style={styles.title}>Admin Panel</Text>

            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.navigate('Geofences')}
            >
              <Text style={styles.buttonText}>Manage Worksites</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.navigate('ManageUsers')}
            >
              <Text style={styles.buttonText}>Manage Users</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.secondaryButton}
              onPress={() => setAdminModalVisible(true)}
            >
              <Text style={styles.buttonText}>Manage Admin Roles</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.card}>
          {avatarUrl && avatarUrl in Avatars ? (
            <Image
              source={Avatars[avatarUrl as AvatarKey]}
              style={styles.avatar}
              resizeMode="cover"
            />
          ) : (
            <Image
              source={require('../../assets/Pizza Wala Logo.png')}
              style={styles.logo}
              resizeMode="contain"
            />
          )}
          <Text style={styles.title}>{welcomeText}</Text>

          {selectedWorksite && (
            <Text style={styles.subtitle}>Selected: {selectedWorksite.name}</Text>
          )}

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('Chat')}
          >
            <Text style={styles.buttonText}>Open Chat</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.secondaryButton} onPress={handleNavigatorPress}>
            <Text style={styles.buttonText}>Navigate to Worksite</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={() => navigation.navigate('EditProfile')}
          >
            <Text style={styles.buttonText}>Edit Profile</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.logoutButton}
            onPress={() => {
              Alert.alert('Logout', 'Are you sure you want to sign out?', [
                { text: 'Cancel', style: 'cancel' },
                {
                  text: 'Sign Out',
                  style: 'destructive',
                  onPress: async () => {
                    try {
                      await signOutUser();
                      navigation.replace('Login');
                    } catch (e) {
                      console.warn('Sign out failed', e);
                      Alert.alert('Error', 'Unable to sign out.');
                    }
                  },
                },
              ]);
            }}
          >
            <Text style={styles.buttonText}>Logout</Text>
          </TouchableOpacity>
        </View>
      </View>

      <Modal visible={adminModalVisible} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Update Admin Role</Text>
            <Text style={styles.modalSub}>Enter the user email to update.</Text>
            <TextInput
              style={styles.input}
              value={adminEmail}
              onChangeText={setAdminEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              placeholder="name@example.com"
            />
            <View style={styles.toggleRow}>
              <Text style={styles.toggleLabel}>
                {grantAdmin ? 'Grant admin access' : 'Remove admin access'}
              </Text>
              <Switch value={grantAdmin} onValueChange={setGrantAdmin} />
            </View>
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalLink}
                onPress={() => setAdminModalVisible(false)}
              >
                <Text style={styles.modalLinkText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={handleAdminRoleUpdate}
                disabled={adminSaving}
              >
                {adminSaving ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.modalButtonText}>Update Role</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={worksitePickerVisible} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Select Worksite</Text>
            <Text style={styles.modalSub}>Choose a worksite to navigate to.</Text>
            <View style={styles.worksiteList}>
              {sortedWorksites.map(worksite => (
                <TouchableOpacity
                  key={worksite.id}
                  style={styles.worksiteRow}
                  onPress={() => handleSelectWorksite(worksite)}
                >
                  <Text style={styles.worksiteName}>{worksite.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalLink}
                onPress={() => setWorksitePickerVisible(false)}
              >
                <Text style={styles.modalLinkText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: '#e77f39',
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    width: '85%',
    backgroundColor: '#fff9d6',
    borderRadius: 18,
    padding: 24,
    alignItems: 'center',
    elevation: 6,
    marginBottom: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    marginBottom: 12,
  },
  logo: {
    width: 160,
    height: 72,
    marginBottom: 8,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 8,
    borderWidth: 3,
    borderColor: '#f1a55b',
  },
  button: {
    width: '100%',
    backgroundColor: '#f1a55b',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 16,
  },
  secondaryButton: {
    width: '100%',
    backgroundColor: '#f6c07a',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 6,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  logoutButton: {
    width: '100%',
    backgroundColor: '#e77f39',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 12,
  },
  link: {
    marginTop: 12,
  },
  linkText: {
    fontSize: 14,
    textDecorationLine: 'underline',
  },
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  modalCard: {
    width: '100%',
    maxWidth: 420,
    backgroundColor: '#fff9d6',
    borderRadius: 18,
    padding: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 6,
    textAlign: 'center',
  },
  modalSub: {
    textAlign: 'center',
    color: '#3D352E',
    marginBottom: 12,
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 12,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  toggleLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#3D352E',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  modalLink: {
    marginRight: 16,
  },
  modalLinkText: {
    fontSize: 14,
  },
  modalButton: {
    backgroundColor: '#3D352E',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
  },
  modalButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  worksiteList: {
    maxHeight: 240,
    marginBottom: 12,
  },
  worksiteRow: {
    paddingVertical: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#e1d3a5',
  },
  worksiteName: {
    fontSize: 15,
    color: '#3D352E',
  },
});
