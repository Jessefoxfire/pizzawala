// ChatScreen.tsx — full rewrite, offline-safe

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ActivityIndicator,
  Image,
  Alert,
  Modal,
} from 'react-native';
import { Avatars, type AvatarKey } from '../../assets/avatars';
import { db, auth } from '../services/firebase';
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  serverTimestamp,
  doc,
  updateDoc,
  deleteDoc,
} from 'firebase/firestore';

export default function ChatScreen({ navigation }: any) {
  const [messages, setMessages] = useState<any[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editingMessage, setEditingMessage] = useState<any | null>(null);
  const [editText, setEditText] = useState('');
  const [editSaving, setEditSaving] = useState(false);

  const flatListRef = useRef<FlatList>(null);
  const user = auth.currentUser;

  const resolveAvatarSource = (avatar?: string | null) => {
    if (!avatar) return null;
    if (avatar.startsWith('http')) return { uri: avatar };
    if (avatar in Avatars) return Avatars[avatar as AvatarKey];
    return null;
  };

  /* ───────────────────────── user profile (listener) ───────────────────────── */

  useEffect(() => {
    if (!user?.uid) return;

    const unsub = onSnapshot(
      doc(db, 'users', user.uid),
      { includeMetadataChanges: true },
      snap => {
        if (snap.exists()) {
          setUserProfile(snap.data());
        }
      }
    );

    return () => unsub();
  }, [user?.uid]);

  /* ───────────────────────── chat messages (listener) ───────────────────────── */

  useEffect(() => {
    const q = query(
      collection(db, 'chats/team-1/messages'),
      orderBy('createdAt', 'asc')
    );

    const unsub = onSnapshot(
      q,
      { includeMetadataChanges: true },
      snapshot => {
        const msgs = snapshot.docs.map(d => ({
          id: d.id,
          ...d.data(),
        }));
        setMessages(msgs);
        setIsLoading(false);
      }
    );

    return () => unsub();
  }, []);

  /* ───────────────────────── send message ───────────────────────── */

  const sendMessage = async () => {
    if (!inputText.trim() || !user) return;

    const text = inputText;
    setInputText('');

    const fallbackName =
      userProfile?.name || user.displayName || user.email || 'User';
    const fallbackAvatar = userProfile?.avatarUrl ?? null;

    await addDoc(collection(db, 'chats/team-1/messages'), {
      text,
      senderId: user.uid,
      senderName: fallbackName,
      senderAvatar: fallbackAvatar,
      createdAt: serverTimestamp(),
    });
  };

  const openEditModal = (message: any) => {
    setEditingMessage(message);
    setEditText(message.text || '');
    setEditModalVisible(true);
  };

  const handleEditSave = async () => {
    if (!editingMessage || !user?.uid) return;
    const trimmed = editText.trim();
    if (!trimmed) return;

    setEditSaving(true);
    try {
      await updateDoc(doc(db, 'chats/team-1/messages', editingMessage.id), {
        text: trimmed,
        editedAt: serverTimestamp(),
      });
      setEditModalVisible(false);
      setEditingMessage(null);
    } finally {
      setEditSaving(false);
    }
  };

  const handleDelete = (message: any) => {
    Alert.alert('Delete message', 'Delete this message for everyone?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          await deleteDoc(doc(db, 'chats/team-1/messages', message.id));
        },
      },
    ]);
  };

  /* ───────────────────────── render ───────────────────────── */

  const renderMessage = ({ item }: { item: any }) => {
    const isMe = item.senderId === user?.uid;
    const avatarValue = isMe
      ? userProfile?.avatarUrl || item.senderAvatar || 'pizzaMaker'
      : item.senderAvatar;
    const avatarSource = resolveAvatarSource(avatarValue);
    const displayName = isMe ? 'You' : item.senderName;

    return (
      <TouchableOpacity
        activeOpacity={0.8}
        onLongPress={() => {
          if (!isMe) return;
          Alert.alert('Message options', '', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Edit', onPress: () => openEditModal(item) },
            { text: 'Delete', style: 'destructive', onPress: () => handleDelete(item) },
          ]);
        }}
      >
        <View
          style={[
            styles.messageBubble,
            isMe ? styles.myMessage : styles.theirMessage,
          ]}
        >
          <View style={[styles.senderHeader, isMe && styles.senderHeaderMe]}>
            {avatarSource && (
              <Image
                source={avatarSource}
                style={[styles.miniAvatar, isMe && styles.miniAvatarMe]}
              />
            )}
            <Text style={styles.senderName}>{displayName}</Text>
          </View>

          <Text
            style={[
              styles.messageText,
              isMe ? styles.myMessageText : styles.theirMessageText,
            ]}
          >
            {item.text}
          </Text>
          {isMe && (
            <View style={styles.messageActions}>
              <TouchableOpacity
                style={[styles.actionBtn, styles.actionEdit]}
                onPress={() => openEditModal(item)}
              >
                <Text style={styles.actionText}>Edit</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.actionBtn, styles.actionDelete]}
                onPress={() => handleDelete(item)}
              >
                <Text style={styles.actionText}>Delete</Text>
              </TouchableOpacity>
            </View>
          )}
          {item.editedAt && <Text style={styles.editedText}>Edited</Text>}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backButton}>‹ Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Team Chat</Text>
        <View style={{ width: 50 }} />
      </View>

      {isLoading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#FEF6E4" />
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          onContentSizeChange={() =>
            flatListRef.current?.scrollToEnd({ animated: true })
          }
        />
      )}

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Type a message…"
            value={inputText}
            onChangeText={setInputText}
            multiline
          />
          <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
            <Text style={styles.sendButtonText}>Send</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      <Modal visible={editModalVisible} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Edit Message</Text>
            <TextInput
              style={styles.modalInput}
              value={editText}
              onChangeText={setEditText}
              multiline
            />
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalLink}
                onPress={() => setEditModalVisible(false)}
              >
                <Text style={styles.modalLinkText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={handleEditSave}
                disabled={editSaving || !editText.trim()}
              >
                {editSaving ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.modalButtonText}>Save</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

/* ───────────────────────── styles ───────────────────────── */

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#e77f39' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FEF6E4',
  },
  backButton: { fontSize: 18, color: '#3D352E', fontWeight: '600' },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#3D352E' },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  listContent: { padding: 16 },
  messageBubble: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 16,
    marginBottom: 8,
  },
  myMessage: { alignSelf: 'flex-end', backgroundColor: '#3D352E' },
  theirMessage: { alignSelf: 'flex-start', backgroundColor: '#FEF6E4' },
  senderHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  senderHeaderMe: {
    justifyContent: 'flex-end',
    flexDirection: 'row-reverse',
  },
  miniAvatar: { width: 40, height: 40, marginRight: 8, borderRadius: 20 },
  miniAvatarMe: { marginRight: 0, marginLeft: 8 },
  senderName: { fontSize: 12, fontWeight: 'bold', color: '#8F6A48' },
  messageText: { fontSize: 16 },
  myMessageText: { color: '#FFF' },
  theirMessageText: { color: '#3D352E' },
  editedText: {
    marginTop: 4,
    fontSize: 10,
    color: '#8F6A48',
  },
  messageActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 8,
    marginTop: 8,
  },
  actionBtn: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  actionEdit: {
    backgroundColor: '#8F6A48',
  },
  actionDelete: {
    backgroundColor: '#d35400',
  },
  actionText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 12,
    backgroundColor: '#FEF6E4',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    backgroundColor: '#FFF',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    fontSize: 16,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: '#e77f39',
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  sendButtonText: { color: '#FFF', fontWeight: 'bold' },
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  modalCard: {
    width: '100%',
    maxWidth: 420,
    backgroundColor: '#fff9d6',
    borderRadius: 18,
    padding: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 10,
    textAlign: 'center',
  },
  modalInput: {
    backgroundColor: '#fff',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    minHeight: 80,
    marginBottom: 12,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  modalLink: {
    marginRight: 16,
  },
  modalLinkText: {
    fontSize: 14,
  },
  modalButton: {
    backgroundColor: '#3D352E',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
  },
  modalButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
});
