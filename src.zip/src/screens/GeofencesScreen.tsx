import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Switch,
  Alert,
  Modal,
  TextInput,
  SafeAreaView,
  ActivityIndicator,
  PermissionsAndroid,
  Platform,
} from 'react-native';
import Geolocation from 'react-native-geolocation-service';
import Slider from '@react-native-community/slider';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import {
  collection,
  query,
  onSnapshot,
  doc,
  updateDoc,
  addDoc,
  serverTimestamp,
  writeBatch,
} from 'firebase/firestore';

import { db, auth } from '../services/firebase';
import { RootStackParamList } from '../navigation/AppNavigator';
import { Icons } from '../components/Icons';

type Props = NativeStackScreenProps<RootStackParamList, 'Geofences'>;

export default function GeofencesScreen({ navigation }: Props) {
  const [geofences, setGeofences] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);

  const [name, setName] = useState('');
  const [radius, setRadius] = useState(50);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [saving, setSaving] = useState(false);
  const [locating, setLocating] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const saveWatchdogRef = useRef<NodeJS.Timeout | null>(null);

  // Helper: race a promise against a timeout (ms)
  const promiseTimeout = async <T,>(p: Promise<T>, ms: number): Promise<T> => {
    let timeoutId: NodeJS.Timeout;
    const timeout = new Promise<never>((_, reject) => {
      timeoutId = setTimeout(() => reject(new Error('timeout')), ms);
    });
    try {
      const res = await Promise.race([p, timeout]);
      clearTimeout(timeoutId!);
      return res as T;
    } catch (e) {
      clearTimeout(timeoutId!);
      throw e;
    }
  };

  const mounted = useRef(true);
  const user = auth.currentUser;

  /* ───────────────────────── lifecycle ───────────────────────── */

  useEffect(() => {
    mounted.current = true;
    const q = query(collection(db, 'geofences'));
    const unsub = onSnapshot(q, snap => {
      if (!mounted.current) return;
      const items = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setGeofences(items);
      setSelectedIds(prev => {
        if (prev.size === 0) return prev;
        const validIds = new Set(items.map(item => item.id));
        const next = new Set(Array.from(prev).filter(id => validIds.has(id)));
        return next.size === prev.size ? prev : next;
      });
      setLoading(false);
    });
    return () => {
      mounted.current = false;
      if (saveWatchdogRef.current) {
        clearTimeout(saveWatchdogRef.current);
        saveWatchdogRef.current = null;
      }
      unsub();
    };
  }, []);

  /* ───────────────────────── permissions ───────────────────────── */

  const ensureLocationPermission = async () => {
    console.log('Checking location permission...');
    
    if (Platform.OS === 'ios') {
      try {
        const authStatus = await Geolocation.requestAuthorization('whenInUse');
        console.log('iOS auth status:', authStatus);
        
        if (authStatus === 'granted') {
          return true;
        }
        
        Alert.alert(
          'Location Permission Required',
          'Please enable location access in Settings > PizzaWala > Location',
          [{ text: 'OK' }]
        );
        return false;
      } catch (err) {
        console.error('iOS permission error:', err);
        return false;
      }
    }

    if (Platform.OS !== 'android') return true;

    const result = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      {
        title: 'Location Access',
        message: 'Location is required to set a worksite center.',
        buttonPositive: 'Allow',
        buttonNegative: 'Cancel',
      }
    );

    const granted = result === PermissionsAndroid.RESULTS.GRANTED;
    console.log('Android permission granted:', granted);
    return granted;
  };

  /* ───────────────────────── location ───────────────────────── */

  const getCurrentLocation = async () => {
    if (locating) return;

    const granted = await ensureLocationPermission();
    if (!granted) {
      Alert.alert('Permission denied', 'Location access is required.');
      return;
    }

    setLocating(true);
    console.log('Starting location acquisition...');

    try {
      const requestPosition = (options: any) =>
        new Promise<any>((resolve, reject) => {
          Geolocation.getCurrentPosition(resolve, reject, options);
        });

      let pos: any;

      try {
        pos = await requestPosition({
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 0,
          showLocationDialog: true,
          forceRequestLocation: true,
        });
      } catch (err: any) {
        if (err?.code !== 2 && err?.code !== 3) {
          throw err;
        }

        console.warn('High-accuracy location failed, retrying low-accuracy', err);
        pos = await requestPosition({
          enableHighAccuracy: false,
          timeout: 15000,
          maximumAge: 60000,
          showLocationDialog: true,
          forceRequestLocation: true,
        });
      }

      console.log('✅ Location success:', {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
        accuracy: pos.coords.accuracy,
      });

      if (!mounted.current) {
        console.log('Component unmounted, ignoring location');
        return;
      }

      const newLocation = {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
      };

      setLocation(newLocation);
      console.log('Location state updated:', newLocation);
    } catch (err: any) {
      console.error('❌ Location error:', {
        code: err?.code,
        message: err?.message,
        PERMISSION_DENIED: err?.code === 1,
        POSITION_UNAVAILABLE: err?.code === 2,
        TIMEOUT: err?.code === 3,
      });

      if (!mounted.current) return;

      let errorMsg = 'Unable to get location.';
      if (err?.code === 1) {
        errorMsg = 'Location permission denied. Check Settings > PizzaWala > Location.';
      } else if (err?.code === 2) {
        errorMsg = 'Location unavailable. Make sure Location Services are enabled in Settings.';
      } else if (err?.code === 3) {
        errorMsg = 'Location request timed out. Please try again.';
      } else if (err?.message) {
        errorMsg = `Location service failed: ${err.message}`;
      }

      Alert.alert('Location Error', errorMsg);
    } finally {
      if (mounted.current) setLocating(false);
    }
  };

  /* ───────────────────────── save ───────────────────────── */

  const saveGeofence = async () => {
    if (saving) return;
    console.log('saveGeofence: invoked', { name, location, radius, editingId });
    // reset previous error state
    setSaveError(null);
    setMessage('Saving worksite...');
    const trimmedName = name.trim();
    if (!trimmedName || !location) {
      Alert.alert('Error', 'Name and location are required.');
      setMessage(null);
      return;
    }
    if (!editingId) {
      const normalized = trimmedName.toLowerCase();
      const hasDuplicate = geofences.some(
        g => String(g?.name || '').trim().toLowerCase() === normalized
      );
      if (hasDuplicate) {
        Alert.alert('Duplicate', 'A worksite with this name already exists.');
        setMessage(null);
        return;
      }
    }

    setSaving(true);
    setModalVisible(false);
    if (saveWatchdogRef.current) {
      clearTimeout(saveWatchdogRef.current);
    }
    saveWatchdogRef.current = setTimeout(() => {
      if (!mounted.current) return;
      setSaving(false);
      setMessage('Save still in progress...');
    }, 12000);
    try {
      const payload: any = {
        name: trimmedName,
        radiusMeters: radius,
        center: location,
        active: true,
        teamId: 'team-1',
      };

      if (editingId) {
        // Update existing worksite
        console.log('saveGeofence: updating docId=', editingId);
        await updateDoc(doc(db, 'geofences', editingId), payload);
        console.log('saveGeofence: update success');
      } else {
        // Create new worksite
        if (user && user.uid) payload.createdBy = user.uid;
        payload.createdAt = serverTimestamp();
        console.log('saveGeofence: payload=', payload);
        const docRef = await addDoc(collection(db, 'geofences'), payload);
        console.log('saveGeofence: success docId=', docRef.id);
      }

      // Stop spinner, close modal, clear fields
      if (!mounted.current) return;
      if (saveWatchdogRef.current) {
        clearTimeout(saveWatchdogRef.current);
        saveWatchdogRef.current = null;
      }
      setSaving(false);
      setMessage(null);
      setModalVisible(false);
      setEditingId(null);
      setName('');
      setRadius(50);
      setLocation(null);
      // Show confirmation
      Alert.alert('Success', editingId ? 'Worksite updated' : 'New Worksite Created');
    } catch (err: any) {
      console.error('saveGeofence error:', err);
      const msg = err?.message ? String(err.message) : String(err);
      console.error('saveGeofence error (catch):', err);
      if (!mounted.current) return;
      if (saveWatchdogRef.current) {
        clearTimeout(saveWatchdogRef.current);
        saveWatchdogRef.current = null;
      }
      if (msg === 'timeout') {
        // surface retryable timeout
        setSaveError('Save timed out. Check your network and try again.');
        setMessage('Save timed out');
      } else {
        setSaveError(`Save failed: ${msg}`);
        setMessage(`Save failed: ${msg}`);
      }
      Alert.alert('Error', `Save failed: ${msg}`);
      setTimeout(() => setMessage(null), 4000);
    } finally {
      if (mounted.current) setSaving(false);
    }
  };

  const resetModal = () => {
    setName('');
    setRadius(50);
    setLocation(null);
    setEditingId(null);
    setModalVisible(false);
  };

  const openEditModal = (worksite: any) => {
    setName(worksite.name);
    setRadius(worksite.radiusMeters);
    setLocation(worksite.center);
    setEditingId(worksite.id);
    setModalVisible(true);
  };

  const deleteWorksite = (id: string, name: string) => {
    Alert.alert('Delete Worksite', `Are you sure you want to delete "${name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        onPress: async () => {
          try {
            setMessage('Deleting worksite...');
            const batch = writeBatch(db);
            batch.delete(doc(db, 'geofences', id));
            await promiseTimeout(batch.commit(), 10000);
            setMessage(null);
            Alert.alert('Success', 'Worksite deleted');
          } catch (err: any) {
            const msg = err?.message ? String(err.message) : String(err);
            setMessage(null);
            Alert.alert('Error', `Failed to delete worksite: ${msg}`);
          }
        },
        style: 'destructive',
      },
    ]);
  };

  const toggleSelect = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedIds(newSet);
  };

  const deleteSelected = () => {
    if (selectedIds.size === 0) return;
    const ids = Array.from(selectedIds);
    Alert.alert(
      'Delete Worksites',
      `Are you sure you want to delete ${ids.length} worksite(s)?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          onPress: async () => {
            try {
              setMessage(`Deleting ${ids.length} worksite(s)...`);
              const batch = writeBatch(db);
              ids.forEach(id => batch.delete(doc(db, 'geofences', id)));
              await promiseTimeout(batch.commit(), 15000);
              setSelectedIds(new Set());
              setMessage(null);
              Alert.alert('Success', `${ids.length} worksite(s) deleted`);
            } catch (err: any) {
              const msg = err?.message ? String(err.message) : String(err);
              setMessage(null);
              Alert.alert('Error', `Failed to delete worksites: ${msg}`);
            }
          },
          style: 'destructive',
        },
      ]
    );
  };

  /* ───────────────────────── list item ───────────────────────── */

  const renderItem = ({ item }: { item: any }) => {
    const isSelected = selectedIds.has(item.id);
    return (
      <View style={[styles.item, isSelected && styles.itemSelected]}>
        <View style={{flex: 1}}>
          <Text style={styles.itemName}>{item.name}</Text>
          <Text style={styles.itemSub}>Radius: {item.radiusMeters}m</Text>
          <View style={{ flexDirection: 'row', marginTop: 8, gap: 8, alignItems: 'center' }}>
            <TouchableOpacity
              style={styles.checkbox}
              onPress={() => toggleSelect(item.id)}
            >
              <Text style={styles.checkboxText}>{isSelected ? '✓' : ''}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.editBtn}
              onPress={() => openEditModal(item)}
            >
              <Text style={styles.editBtnText}>Edit</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.viewBtn}
              onPress={() => navigation.navigate('WorksiteFinder', { geofence: item })}
            >
              <Text style={styles.viewBtnText}>View location</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.deleteBtn}
              onPress={() => deleteWorksite(item.id, item.name)}
            >
              <Text style={styles.deleteBtnText}>Delete</Text>
            </TouchableOpacity>
          </View>
        </View>
        <Switch
          value={item.active}
          onValueChange={() =>
            updateDoc(doc(db, 'geofences', item.id), { active: !item.active })
          }
        />
      </View>
    );
  };

  /* ───────────────────────── UI ───────────────────────── */

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Icons.home width={28} height={28} color="#2E6B5A" />
        </TouchableOpacity>
        <Text style={styles.title}>Manage Worksites</Text>
        <View style={{ width: 60 }} />
      </View>

      {loading ? (
        <ActivityIndicator size="large" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={geofences}
          renderItem={renderItem}
          keyExtractor={i => i.id}
          contentContainerStyle={styles.list}
          ListEmptyComponent={
            <Text style={styles.empty}>
              No worksites found. Add one to get started!
            </Text>
          }
        />
      )}

      <View style={styles.footer}>
        {selectedIds.size > 0 && (
          <TouchableOpacity style={styles.deleteSelectedBtn} onPress={deleteSelected}>
            <Text style={styles.deleteSelectedText}>
              Delete {selectedIds.size} Worksite{selectedIds.size !== 1 ? 's' : ''}
            </Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity style={styles.addBtn} onPress={() => setModalVisible(true)}>
          <Text style={styles.addText}>+ Add New Worksite</Text>
        </TouchableOpacity>
      </View>

      {/* ───────────── modal ───────────── */}

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalBg}>
          <View style={styles.modal}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {editingId ? 'Edit Worksite' : 'New Worksite'}
              </Text>
              <TouchableOpacity onPress={resetModal} style={styles.closeBtn}>
                <Text style={styles.closeText}>✕</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.label}>Worksite Name</Text>
            <TextInput
              style={styles.input}
              value={name}
              onChangeText={setName}
              placeholder="e.g. Downtown Pizzeria"
            />

            <Text style={styles.label}>Radius (meters): {radius}</Text>
            <Slider
              minimumValue={10}
              maximumValue={500}
              step={5}
              value={radius}
              onValueChange={setRadius}
            />

            <View style={styles.locBtns}>
              <TouchableOpacity style={styles.locBtn} onPress={getCurrentLocation}>
                {locating ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.btnText}>Use Current Location</Text>
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.locBtn, { backgroundColor: '#3D352E' }]}
                onPress={() => {
                  // Close modal before navigating to the full-screen map picker
                  setModalVisible(false);
                  navigation.navigate('MapPicker', {
                    onLocationSelected: (lat, lng) => {
                      setLocation({ lat, lng });
                      // reopen modal when a location is picked
                      setModalVisible(true);
                    },
                  });
                }}
              >
                <Text style={styles.btnText}>Pick on Map</Text>
              </TouchableOpacity>
            </View>

            {location && <Text style={styles.ok}>✓ Location set</Text>}

            <View style={styles.actions}>
              <TouchableOpacity onPress={resetModal}>
                <Text>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.saveBtn}
                onPress={saveGeofence}
                disabled={saving}
              >
                {saving ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.btnText}>
                    {editingId ? 'Update Worksite' : 'Save Worksite'}
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      {saveError && (
        <View style={styles.errorOverlay}>
          <Text style={styles.errorText}>{saveError}</Text>
          <View style={{ flexDirection: 'row', marginTop: 8 }}>
            <TouchableOpacity
              style={[styles.retryBtn, { marginRight: 8 }]}
              onPress={() => {
                setSaveError(null);
                saveGeofence();
              }}
            >
              <Text style={{ color: '#fff' }}>Retry</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.retryBtn, { backgroundColor: '#777' }]}
              onPress={() => setSaveError(null)}
            >
              <Text style={{ color: '#fff' }}>Dismiss</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
      {message && (
        <View style={styles.messageBanner} pointerEvents="none">
          <Text style={styles.messageText}>{message}</Text>
        </View>
      )}
    </SafeAreaView>
  );
}

/* ───────────────────────── styles ───────────────────────── */

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#e77f39' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FEF6E4',
  },
  backBtn: { padding: 4 },
  back: { fontSize: 18, fontWeight: 'bold' },
  title: { fontSize: 20, fontWeight: 'bold' },
  list: { padding: 16 },
  empty: { textAlign: 'center', marginTop: 40, color: '#3D352E' },
  item: {
    backgroundColor: '#FEF6E4',
    padding: 16,
    borderRadius: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  itemSelected: {
    backgroundColor: '#FFE5E5',
    borderWidth: 2,
    borderColor: '#d32f2f',
  },
  checkbox: {
    width: 28,
    height: 28,
    borderWidth: 2,
    borderColor: '#3D352E',
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  checkboxText: { fontSize: 16, color: '#3D352E', fontWeight: 'bold' },
  itemName: { fontSize: 18, fontWeight: 'bold' },
  itemSub: { fontSize: 14 },
  editBtn: {
    backgroundColor: '#3D352E',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 6,
  },
  editBtnText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  viewBtn: {
    backgroundColor: '#2E6B5A',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 6,
  },
  viewBtnText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  deleteBtn: {
    backgroundColor: '#d35400',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 6,
  },
  deleteBtnText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  footer: { padding: 16, backgroundColor: '#FEF6E4' },
  addBtn: {
    backgroundColor: '#3D352E',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  addText: { color: '#fff', fontWeight: 'bold' },
  deleteSelectedBtn: {
    backgroundColor: '#d35400',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
  },
  deleteSelectedText: { color: '#fff', fontWeight: 'bold' },
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
  },
  modal: {
    margin: 20,
    backgroundColor: '#FEF6E4',
    borderRadius: 24,
    padding: 24,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  modalTitle: { fontSize: 22, fontWeight: 'bold', flex: 1 },
  closeBtn: {
    padding: 4,
    marginLeft: 8,
  },
  closeText: {
    fontSize: 28,
    color: '#3D352E',
    fontWeight: '300',
  },
  label: { marginTop: 12, fontWeight: '600' },
  input: { backgroundColor: '#fff', padding: 12, borderRadius: 8 },
  locBtns: { flexDirection: 'row', gap: 10, marginTop: 12 },
  locBtn: {
    flex: 1,
    backgroundColor: '#e77f39',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  btnText: { color: '#fff', fontWeight: 'bold' },
  ok: {
    textAlign: 'center',
    marginTop: 10,
    color: 'green',
    fontWeight: 'bold',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 24,
  },
  saveBtn: {
    backgroundColor: '#3D352E',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  messageBanner: {
    position: 'absolute',
    top: 16,
    left: 16,
    right: 16,
    backgroundColor: 'rgba(0,0,0,0.75)',
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
    zIndex: 999,
  },
  messageText: { color: '#fff', fontWeight: '600' },
  errorOverlay: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 24,
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
    zIndex: 1000,
  },
  errorText: { color: '#3D352E', fontWeight: '600' },
  retryBtn: {
    backgroundColor: '#3D352E',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    alignItems: 'center',
  },
});
