import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  SafeAreaView,
  Image,
  ImageBackground,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { loginWithEmail, resetPassword } from '../services/firebase';
import { RootStackParamList } from '../navigation/AppNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'Login'>;

export default function LoginScreen({ navigation }: Props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  const handleSignIn = async () => {
    const trimmedEmail = email.trim();
    if (!trimmedEmail || !password) {
      Alert.alert('Error', 'Email and password are required.');
      return;
    }

    setIsLoading(true);
    try {
      const credential = await loginWithEmail(trimmedEmail.toLowerCase(), password);
      if (credential?.user) {
        navigation.replace('Permissions');
      } else {
        Alert.alert('Sign In Failed', 'Unable to complete sign-in. Try again.');
      }
    } catch (err: any) {
      const code = String(err?.code || '');
      const friendly =
        code === 'auth/invalid-credential' || code === 'auth/wrong-password'
          ? 'Invalid email or password. Double-check and try again.'
          : code === 'auth/user-not-found'
            ? 'No account found for that email. Try Create Account.'
            : code === 'auth/too-many-requests'
              ? 'Too many attempts. Please wait a moment and try again.'
              : err?.message
                ? String(err.message)
                : 'Unable to sign in.';
      Alert.alert('Sign In Failed', friendly);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPassword = async () => {
    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      Alert.alert('Email required', 'Enter your email to receive a reset link.');
      return;
    }

    setIsResetting(true);
    try {
      await resetPassword(trimmedEmail.toLowerCase());
      Alert.alert('Reset Email Sent', 'Check your inbox for a password reset link.');
    } catch (err: any) {
      const code = String(err?.code || '');
      const friendly =
        code === 'auth/user-not-found'
          ? 'No account found for that email.'
          : err?.message
            ? String(err.message)
            : 'Unable to send reset email.';
      const debug = code ? `\n\nCode: ${code}` : '';
      Alert.alert('Reset Failed', `${friendly}${debug}`);
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={require('../../assets/Flames background.png')}
        style={styles.background}
        resizeMode="cover"
      >
        <View style={styles.content}>
          <Image
            source={require('../../assets/Pizza Wala Logo.png')}
            style={styles.logo}
            resizeMode="contain"
          />
          <Text style={styles.title}>PizzaWala</Text>
          <Text style={styles.subtitle}>
            Welcome to The Pizza Wala Team!{"\n"}
            Create your account or sign in.
          </Text>

          <View style={styles.form}>
            <TextInput
              style={styles.input}
              placeholder="Email"
              placeholderTextColor="#8F6A48"
              autoCapitalize="none"
              keyboardType="email-address"
              value={email}
              onChangeText={setEmail}
            />
            <View style={styles.passwordRow}>
              <TextInput
                style={styles.passwordInput}
                placeholder="Password"
                placeholderTextColor="#8F6A48"
                secureTextEntry={!showPassword}
                value={password}
                onChangeText={setPassword}
              />
              <TouchableOpacity
                style={styles.toggleButton}
                onPress={() => setShowPassword(prev => !prev)}
              >
                <Text style={styles.toggleText}>{showPassword ? 'Hide' : 'Show'}</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.primaryButton}
              onPress={handleSignIn}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="#3D352E" />
              ) : (
                <Text style={styles.primaryButtonText}>Sign In</Text>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.resetButton}
              onPress={handleResetPassword}
              disabled={isResetting}
            >
              {isResetting ? (
                <ActivityIndicator color="#B35412" />
              ) : (
                <Text style={styles.resetButtonText}>Forgot Password?</Text>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.secondaryButton}
              onPress={() => navigation.navigate('CreateAccount')}
            >
              <Text style={styles.secondaryButtonText}>Create Account</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  background: {
    flex: 1,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  logo: {
    width: 160,
    height: 90,
  },
  title: {
    marginTop: 16,
    fontSize: 24,
    fontWeight: '600',
    color: '#2A1D14',
  },
  subtitle: {
    marginTop: 8,
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
    color: '#2A1D14',
    paddingHorizontal: 12,
  },
  form: {
    width: '100%',
    marginTop: 24,
    backgroundColor: 'rgba(255, 242, 230, 0.92)',
    padding: 16,
    borderRadius: 16,
  },
  input: {
    backgroundColor: '#F6C18B',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 10,
    fontSize: 16,
    color: '#3D2B1F',
    marginBottom: 12,
  },
  passwordRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F6C18B',
    borderRadius: 10,
    marginBottom: 12,
  },
  passwordInput: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 14,
    fontSize: 16,
    color: '#3D2B1F',
  },
  toggleButton: {
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  toggleText: {
    color: '#B35412',
    fontWeight: '600',
    fontSize: 13,
  },
  primaryButton: {
    backgroundColor: '#E58F3A',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 4,
  },
  primaryButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2A1D14',
  },
  secondaryButton: {
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  secondaryButtonText: {
    fontSize: 14,
    textDecorationLine: 'underline',
    color: '#B35412',
  },
  resetButton: {
    paddingVertical: 10,
    alignItems: 'center',
    marginTop: 6,
  },
  resetButtonText: {
    fontSize: 13,
    textDecorationLine: 'underline',
    color: '#B35412',
  },
});
