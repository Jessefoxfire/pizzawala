// src/utils/geo.ts

import { PermissionsAndroid, Platform, Alert } from 'react-native';
import Geolocation from 'react-native-geolocation-service';

export async function ensureLocationPermission(): Promise<boolean> {
  if (Platform.OS === 'ios') {
    try {
      await Geolocation.requestAuthorization('whenInUse');
      return true;
    } catch (error) {
      console.warn('iOS location permission error:', error);
      return false;
    }
  }

  // Android
  const fine = await PermissionsAndroid.request(
    PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
  );

  if (fine !== PermissionsAndroid.RESULTS.GRANTED) {
    Alert.alert('Location Permission', 'Please enable location in Settings');
    return false;
  }

  return true;
}

export async function ensureGeofencePermissions(): Promise<boolean> {
  if (Platform.OS !== 'android') return true;

  const fine = await PermissionsAndroid.request(
    PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
  );

  if (fine !== PermissionsAndroid.RESULTS.GRANTED) {
    return false;
  }

  // Background location MUST be requested separately on Android 10+
  if (Platform.Version >= 29) {
    const bg = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_BACKGROUND_LOCATION
    );

    return bg === PermissionsAndroid.RESULTS.GRANTED;
  }

  return true;
}
