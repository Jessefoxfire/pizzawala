// firebase.ts — full rewrite, offline-safe

import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  initializeAuth,
  getReactNativePersistence,
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  type Auth,
  type UserCredential,
} from 'firebase/auth';
import {
  initializeFirestore,
  persistentLocalCache,
  persistentSingleTabManager,
  doc,
  setDoc,
  serverTimestamp,
} from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';

/* ─────────────────────────── config ─────────────────────────── */

const firebaseConfig = {
  projectId: 'pizza-wala-team-x1x24',
  appId: '1:462340348678:android:d39962a12a52763c',
  storageBucket: 'pizza-wala-team-x1x24.appspot.com',
  apiKey: 'AIzaSyDHnpnODxu039eoDVSA0M4C_DsEkimLXMY',
  authDomain: 'pizza-wala-team-x1x24.firebaseapp.com',
  messagingSenderId: '462340348678',
};

/* ─────────────────────────── app ─────────────────────────── */

const app = getApps().length === 0
  ? initializeApp(firebaseConfig)
  : getApp();

/* ─────────────────────────── auth (persisted) ─────────────────────────── */

let authInstance: Auth;
try {
  // Prefer initializeAuth so React Native persistence is applied.
  authInstance = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage),
  });
} catch {
  // If already initialized elsewhere, fall back to the existing instance.
  authInstance = getAuth(app);
}

export const auth: Auth = authInstance;

/* ─────────────────────────── firestore (offline-first) ─────────────────────────── */

export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentSingleTabManager(),
  }),
  experimentalForceLongPolling: true,
});

/* ─────────────────────────── api ─────────────────────────── */

export const loginWithEmail = (email: string, password: string) =>
  signInWithEmailAndPassword(auth, email, password);

export const resetPassword = (email: string) =>
  sendPasswordResetEmail(auth, email);

export const createAccountWithEmail = async (
  name: string,
  email: string,
  password: string,
  avatarUrl: string
): Promise<UserCredential> => {
  const userCredential = await createUserWithEmailAndPassword(
    auth,
    email,
    password
  );

  const { user } = userCredential;
  const normalizedEmail = email.trim().toLowerCase();

  await setDoc(
    doc(db, 'users', user.uid),
    {
      uid: user.uid,
      name,
      email,
      emailLower: normalizedEmail,
      avatarUrl,
      roles: ['member'],
      teamId: 'team-1',
      createdAt: serverTimestamp(),
    },
    { merge: true }
  );

  return userCredential;
};

export const signOutUser = () => signOut(auth);
