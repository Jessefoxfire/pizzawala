import React from 'react';
import {
  View,
  ActivityIndicator,
  StyleSheet,
  Text,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { useAuth } from '../auth/useAuth';

import LoginScreen from '../screens/LoginScreen';
import CreateAccountScreen from '../screens/CreateAccountScreen';
import HomeScreen from '../screens/HomeScreen';
import GeofencesScreen from '../screens/GeofencesScreen';
import WorksiteFinderScreen from '../screens/WorksiteFinderScreen';
import ChatScreen from '../screens/ChatScreen';
import MapPickerScreen from '../screens/MapPickerScreen';
import PermissionsScreen from '../screens/PermissionsScreen';
import ManageUsersScreen from '../screens/ManageUsersScreen';
import EditProfileScreen from '../screens/EditProfileScreen';

import { Geofence } from '../utils/types';

export type RootStackParamList = {
  Login: undefined;
  CreateAccount: undefined;
  Permissions: undefined;
  Home: undefined;
  Geofences: undefined;
  ManageUsers: undefined;
  EditProfile: undefined;
  WorksiteFinder: { geofence: Geofence };
  Chat: undefined;
  MapPicker: { onLocationSelected: (lat: number, lng: number) => void };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function AppNavigator() {
  const auth = useAuth();

  /* ───────────────────────── AUTH LOADING ───────────────────────── */

  if (auth.status === 'loading') {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#FEF6E4" />
        <Text style={styles.loadingText}>
          Loading your dashboard…
        </Text>
      </View>
    );
  }

  /* ───────────────────────── NAVIGATION ───────────────────────── */

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {auth.status === 'signedOut' ? (
          <>
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen
              name="CreateAccount"
              component={CreateAccountScreen}
            />
          </>
        ) : (
          <>
            <Stack.Screen name="Permissions" component={PermissionsScreen} />
            <Stack.Screen name="Home" component={HomeScreen} />
            <Stack.Screen name="Geofences" component={GeofencesScreen} />
            <Stack.Screen name="ManageUsers" component={ManageUsersScreen} />
            <Stack.Screen name="EditProfile" component={EditProfileScreen} />
            <Stack.Screen
              name="WorksiteFinder"
              component={WorksiteFinderScreen}
            />
            <Stack.Screen name="Chat" component={ChatScreen} />
            <Stack.Screen name="MapPicker" component={MapPickerScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

/* ───────────────────────── STYLES ───────────────────────── */

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    backgroundColor: '#e77f39',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#FEF6E4',
    fontWeight: '500',
  },
});
